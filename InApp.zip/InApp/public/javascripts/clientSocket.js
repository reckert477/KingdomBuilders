var socket = io.connect('/');
var name = "";
socket.on('newComment', function (data) {
  $("#displayArea").append(data.c);
});

socket.on('updateFood', function (data) {
  $("#foodPlace").text(data.r);
});

socket.on('updateWood', function (data) {
  $("#woodPlace").text(data.r);
});

socket.on('updateEvent', function (data) {
  $("#eventArea").text(data.e);
});

socket.on('roleChanged', function (data) {
  $("#farmerPlace").text(data.f);
  $("#woodsmanPlace").text(data.w);
  $("#militiaPlace").text(data.m);
});

function buttonClicked() {
	socket.emit('message', {c: name+"<br>"+$("#input_area").val()+"<br><br>"});
	$("#input_area").val("");
}

function nameSubmit() {
	name = $("#name_input").val();
	$("#name_input").val("");
}

function becomeFarmer() {
	socket.emit('changeRole', {n: 1});
}

function becomeWoodsman() {
	socket.emit('changeRole', {n: 2});
}

function becomeMilitia() {
	socket.emit('changeRole', {n: 3});
}


