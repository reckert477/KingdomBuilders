exports.init = function(io) {
	var wood = 0;
	var food = 0;
	var food_unit = 2;
	var wood_unit = 2;
	var farmers = 0;
	var woodsmen = 0;
	var militia = 0;
	

	io.sockets.on('connection', function (socket) {

		var role = 0; // 0 = nothing, 1 = farmer, 2 = woodsman, 3 = militia

		socket.on('message', function (msg){
		 	socket.emit('newComment', msg)
		 	socket.broadcast.emit('newComment', msg);
		});

		socket.on('changeRole', function (msg){
			let old_role = role;
			if(old_role == 1){
				farmers -= 1;
			}
			else if(old_role == 2){
				woodsmen -= 1;
			}
			else if(old_role == 3){
				militia -= 1;
			}

			if(msg.n == 1){
				role = 1;
				farmers += 1;
			}
			else if(msg.n == 2){
				role = 2;
				woodsmen += 1;
			}
			else if(msg.n == 3){
				role = 3;
				militia += 1;
			}
			socket.emit('roleChanged', {f: farmers, w: woodsmen, m: militia});
			socket.broadcast.emit('roleChanged', {f: farmers, w: woodsmen, m: militia});
		});

		setInterval(function() {  
			if(role == 1){
	  			food += food_unit;
	  		}
	  		else if(role == 2){
	  			wood += wood_unit;
	  		}
	  		socket.emit('updateFood', { r: food });
	  		socket.broadcast.emit('updateFood', { r: food });
	  		socket.emit('updateWood', { r: wood });
	  		socket.broadcast.emit('updateWood', { r: wood });
	  		//below added so that new people can see the amount of people in roles
	  		socket.emit('roleChanged', {f: farmers, w: woodsmen, m: militia});
			socket.broadcast.emit('roleChanged', {f: farmers, w: woodsmen, m: militia});
		}, 3000);

		socket.on('disconnect', function(){

		});
	});
	setInterval(function() {
			let rerolls = militia;
			let x;
			while(rerolls >= 0){ // assuming no way for militia to be less than 0
				x = parseInt(Math.random() * 6);
				console.log(x);
				if(x == 0 || x == 1 || x == 2)
					break;
				else
					rerolls -= 1;
			}
			//will try to integrate militia afterwards.
			//after that, should try tackling voting and building queue
			let string = "";
			food_unit = 2;
			wood_unit = 2;

			if(x == 0){
				string = "The day is sunny and everyone is in a good mood.";
			}
			else if(x == 1){
				string = "The villagers are happy, and decide to throw a small festival.";
			}
			else if(x == 2){
				string = "The day is sunny and everyone is in a good mood.";
			}
			else if(x == 3){
				string = "A flood seems to come from nowhere, and takes out a large chunk of the food.";
				io.emit('updateFood', { r: food });
				food = Math.floor(food * 3 / 4);
			}
			else if(x == 4){
				string = "A famine hits the land, causing the farmers to harvest less food for the next few days.";
				food_unit = 1;
			}
			else{ // x == 5
				string = "A forest fire ravages the wilderness, causing the woodsmen to bring back less wood for the next few days.";
				wood_unit = 1;
			}
			io.emit('updateEvent', { e: string});
	}, 10000);
}
